#include<cstdio>
#include<cstring>
const int N = 10000005;
int book[N],ans[N],Case;
void query(int l,int r)
{
	if(!l||!r){
		printf("Illegal\n");
		return ;
	}
	if(r<l){
		printf("Illegal\n");
		return ;
	}
	for(int i=l;i<r;i++)
		printf("%d ",ans[i]);
	printf("%d\n",ans[r]);
	return ;
}
int main()
{
	freopen("Advertising.in","r",stdin);
	freopen("Advertising.out","w",stdout);
	scanf("%d",&Case);
	for(int c=1;c<=Case;c++){
		printf("Case %d :\n",c);
		int n,maxr=0;
		scanf("%d",&n);
		for(int i=1;i<=n;i++){
			int l,r;
			scanf("%d %d",&l,&r);
			book[l]++;book[r+1]--;
			if(r>maxr) maxr=r;
		}
		printf("Query Now\n");
		int s=0;
		for(int i=1;i<=maxr;i++){
			s+=book[i];
			ans[i]=s;
		}
		int l,r,tot=0;
		while(scanf("%d %d",&l,&r),(l||r)){
			tot++;
			query(l,r);
		}
		printf("the Number of Queries : %d\n",tot);
		memset(ans,0,sizeof(ans));
		memset(book,0,sizeof(book));
	}
	return 0;
}
