#include<iostream>
#include<string>
#include<cctype>
using namespace std;
string Last,Next;
int main()
{
    bool first=true;
    int tot=0,ans=0;
    while (cin>>Next)
    {
        tot++;
        if(first){
            Last=Next;
            first=false;
            ans++;
            continue;
        }
        int lenl=Last.length(),lenn=Next.length();
        char l=Last[lenl-1],n=Next[0];
        if(isupper(l)) l+=32;
        if(isupper(n)) n+=32;
        if(l==n){
            //cout<<endl<<"***"<<Last<<" and "<<Next<<"***"<<endl;
            Last[lenl-1]=Next[lenn-1];
            continue;
        }
        ans++;
        Last=Next;
    }
    cout<<tot<<endl<<ans<<endl;
    return 0;
}